package sk.tuke.bp;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import java.util.ArrayList;
import java.util.List;


public class Sekcie extends AppCompatActivity   {

    RecyclerView recyclerView;
    RecyclerView.Adapter adapter;
    List<Sekcia> sekcias;
    private SekciaAdapter.RecyclerViewClickListener listener;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_sekcie_recyclerview);


        AppDatabase db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "production")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();

        sekcias = db.SekciaDao().getAllSekcias();

        setOnClickListener();
        recyclerView = findViewById(R.id.rv_sekcie_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new SekciaAdapter(sekcias,listener);
        recyclerView.setAdapter(adapter);



        Toast.makeText(this, "Sekcie", Toast.LENGTH_SHORT).show();
    }

    private void setOnClickListener() {
        listener = new SekciaAdapter.RecyclerViewClickListener() {
            @Override
            public void onClick(View v, int position) {
                    Intent intent = new Intent(getApplicationContext(),QRkod.class);
                    String vysledok = sekcias.get(position).getCislosekcie() +";"+ sekcias.get(position).getCislozvierat();
                    intent.putExtra("vysledok",vysledok);
                    startActivity(intent);
            }
        };
    }
}