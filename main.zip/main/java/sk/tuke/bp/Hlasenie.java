package sk.tuke.bp;

import android.widget.TextView;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.text.DateFormat;
import java.util.Calendar;


@Entity
public class Hlasenie   {

    public Hlasenie( String cislosekcie, String cislozvierat, String cislofarmy, int pocetkusov, String kodudalosti) {

        this.cislosekcie = cislosekcie ;
        this.cislozvierat = cislozvierat;
        this.cislofarmy = cislofarmy;
        this.pocetkusov = pocetkusov;
        this.kodudalosti = kodudalosti;

        Calendar calendar = Calendar.getInstance();
        this.datum = DateFormat.getDateInstance().format(calendar.getTime());
    }
    @PrimaryKey(autoGenerate = true)
    private int id;

    @ColumnInfo(name = "datum")
    private String datum;

    @ColumnInfo(name = "cislosekcie")
    private String cislosekcie;


    @ColumnInfo(name = "cislozvierat")
    private String cislozvierat;

    @ColumnInfo(name = "cislofarmy")
    private String cislofarmy;

    @ColumnInfo(name = "pocetkusov")
    private int pocetkusov;

    @ColumnInfo(name = "kodudalosti")
    private String kodudalosti;




    //Getre
    public int getId() {
        return id;
    }

    public String getDatum() {return datum;
    }

    public String getCislosekcie() {return cislosekcie;
    }


    public String getCislozvierat() {return cislozvierat;
    }

    public String getCislofarmy() {return cislofarmy;
    }


    public int getPocetkusov() {
        return pocetkusov;
    }

    public String getKodudalosti() { return kodudalosti;  }

    //Setre
    public void setId(int id) {
        this.id = id;
    }

    public void setDatum(String datum) {
        this.datum = datum;
    }

    public void setCislosekcie(String cislosekcie) {
        this.cislosekcie = cislosekcie;
    }

    public void setCislofarmy(String cislofarmy) {
        this.cislofarmy = cislofarmy;
    }

    public void setCislozvierat(String cislozvierat) {
        this.cislozvierat = cislozvierat;
    }

    public void setPocetkusov(int pocetkusov) {
        this.pocetkusov = pocetkusov;
    }

    public void setKodudalosti(String kodudalosti) {
        this.kodudalosti = kodudalosti;
    }


}
