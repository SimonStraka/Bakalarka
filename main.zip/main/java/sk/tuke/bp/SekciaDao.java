package sk.tuke.bp;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
interface SekciaDao {
    @Query("SELECT * FROM sekcia")
    List<Sekcia> getAllSekcias();

    @Delete
    void Delete(Sekcia sekcia);

    @Insert
    void insertAll(Sekcia... sekcias);

    @Query("UPDATE sekcia SET pocetkusov = pocetkusov - :pocet WHERE cislosekcie = :cislosekcie")
    void updatePocetZvierat(String cislosekcie, int pocet);



}
