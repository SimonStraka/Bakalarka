package sk.tuke.bp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import java.text.DateFormat;
import java.util.Calendar;

public class CreateHlasenie extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    EditText Nazovsekcie;
    EditText Cislozvierat;
    EditText Pocetkusov;
    EditText Cislofarmy;
    Spinner Kodudalosti;
    Button button;
    String Kod = " ";


    @Override
    protected void onCreate(@Nullable Bundle saveInstanceState) {
        super.onCreate(saveInstanceState);
        setContentView(R.layout.layout_hlasenie);

        Nazovsekcie = findViewById(R.id.nazovsekcie);
        Cislofarmy = findViewById(R.id.cislofarmy1);
        Cislozvierat = findViewById(R.id.cislozvierat);
        Pocetkusov = findViewById(R.id.pocetkusov);
        Kodudalosti = findViewById(R.id.kodudalosti);
        button = findViewById(R.id.Odoslať);

        final AppDatabase db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "production")
                .allowMainThreadQueries()
                .build();




        button.setOnClickListener((view) -> {

            int novypocetkusov = Integer.parseInt(Pocetkusov.getText().toString());

            /*if(novypocetkusov > starypocetkusov )
            Toast
            return;
             */

            Hlasenie hlasenie = new Hlasenie(Nazovsekcie.getText().toString(), Cislozvierat.getText().toString(), Cislofarmy.getText().toString(), novypocetkusov,Kod);


            db.HlasenieDao().insertAll(hlasenie);
            startActivity(new Intent(CreateHlasenie.this, Menu.class));
            Toast.makeText(this, "Hlásenie bolo pridané", Toast.LENGTH_SHORT).show();
            db.SekciaDao().updatePocetZvierat(Nazovsekcie.getText().toString(),novypocetkusov);

        });

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.kody, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Kodudalosti.setAdapter(adapter);
        Kodudalosti.setOnItemSelectedListener(this);

        try {

            String Vysledoks = getIntent().getExtras().getString("vysledoks");
            String Vysledokz = getIntent().getExtras().getString("vysledokz");

            Nazovsekcie.setText(Vysledoks);
            Cislozvierat.setText(Vysledokz);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        Kod = Kodudalosti.getItemAtPosition(i).toString();

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }


}
