package sk.tuke.bp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

public class CreateSekcia extends AppCompatActivity {

    EditText Nazovsekcie;
    EditText Cislozvierat;
    EditText Pocetkusov;
    Button button;

    @Override
    protected void onCreate(@Nullable Bundle saveInstanceState){
        super.onCreate(saveInstanceState);
        setContentView(R.layout.layout_pridatsekciu);

        Nazovsekcie = findViewById(R.id.nazovsekcie);
        Cislozvierat = findViewById(R.id.cislozvierat);
        Pocetkusov = findViewById(R.id.pocetkusov);
        button = findViewById(R.id.button);

        final AppDatabase db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "production")
                .allowMainThreadQueries()
                .build();



        button.setOnClickListener((view) ->{
            int pocetkusov = Integer.parseInt(Pocetkusov.getText().toString());
            Sekcia sekcia = new Sekcia(Nazovsekcie.getText().toString(), Cislozvierat.getText().toString(),pocetkusov);
            db.SekciaDao().insertAll(sekcia);
            startActivity(new Intent(CreateSekcia.this, Menu.class));
            Toast.makeText(this, "Sekcia bola pridana", Toast.LENGTH_SHORT).show();
        });


    }

}
