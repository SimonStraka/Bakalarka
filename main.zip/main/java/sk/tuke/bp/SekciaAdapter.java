package sk.tuke.bp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class SekciaAdapter extends RecyclerView.Adapter<SekciaAdapter.ViewHolder> implements View.OnClickListener  {

    List<Sekcia> sekcias;
    private RecyclerViewClickListener listener;



    public SekciaAdapter(List<Sekcia> sekcias,RecyclerViewClickListener listener){
        this.sekcias = sekcias;
        this.listener = listener;
    }



    @NonNull
    @Override
    public SekciaAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.sekcia_row,parent,false);
        return new ViewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull SekciaAdapter.ViewHolder holder, int position) {
        holder.Cislosekcie.setText(sekcias.get(position).getCislosekcie());
        holder.Cislozvierat.setText(sekcias.get(position).getCislozvierat());
        holder.Pocetkusov.setText(String.valueOf(sekcias.get(position).getPocetkusov()));
    }

    @Override
    public int getItemCount() {
        return sekcias.size();
    }

    @Override
    public void onClick(View view) {

    }


    public interface RecyclerViewClickListener{
        void onClick(View v, int position);
    }

    public class ViewHolder extends  RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView Cislosekcie;
        public TextView Cislozvierat;
        public TextView Pocetkusov;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            Cislosekcie = itemView.findViewById(R.id.nazovsekcie);
            Cislozvierat = itemView.findViewById(R.id.cislozvierat);
            Pocetkusov = itemView.findViewById(R.id.pocetkusov);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {

            listener.onClick(view, getAdapterPosition());
        }
    }
}
