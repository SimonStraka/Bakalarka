package sk.tuke.bp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import java.util.List;

public class Statistika extends AppCompatActivity implements AdapterView.OnItemSelectedListener{
    Spinner Metrika;
    String Vybrane = " ";
    AppDatabase db;
    TableLayout tableLayout;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.statistika);


        Metrika = findViewById(R.id.parameter);
        tableLayout=findViewById(R.id.tableLayout);
         db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "production")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();

        ArrayAdapter<CharSequence> parameter = ArrayAdapter.createFromResource(this, R.array.parameter, android.R.layout.simple_spinner_item);
        parameter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Metrika.setAdapter(parameter);
        Metrika.setOnItemSelectedListener(this);

    }


    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

        tableLayout.removeAllViews();

        Vybrane = Metrika.getItemAtPosition(i).toString();


        switch (Vybrane){
            case "Počet kusov":
                VypisPocetkusov();
            case "Kódy":
                VypisKody();
        }
    }

    private void VypisPocetkusov() {

        List<Sekcia> sekcias = db.SekciaDao().getAllSekcias();
        int spolu = 0;
        for(Sekcia sekcia:sekcias){
            View tableRow = LayoutInflater.from(this).inflate(R.layout.statistika_pocetkusov,null,false);
            TextView cislosekcietabulka  = tableRow.findViewById(R.id.cislosekcietabulka);
            TextView pocetkusovtabulka  = tableRow.findViewById(R.id.pocetkusovtabulka);
            TextView cislozvierattabulka  = tableRow.findViewById(R.id.cislozvierattabulka);

            cislosekcietabulka.setText(sekcia.getCislosekcie());
            pocetkusovtabulka.setText(String.valueOf(sekcia.getPocetkusov()));
            cislozvierattabulka.setText(sekcia.getCislozvierat());
            tableLayout.addView(tableRow);

            spolu +=sekcia.getPocetkusov();

        }



        View tableRow = LayoutInflater.from(this).inflate(R.layout.statistika_pocetkusov,null,false);
        TextView cislosekcietabulka  = tableRow.findViewById(R.id.cislosekcietabulka);
        TextView pocetkusovtabulka  = tableRow.findViewById(R.id.pocetkusovtabulka);
        TextView cislozvierattabulka  = tableRow.findViewById(R.id.cislozvierattabulka);

        cislosekcietabulka.setText("Spolu");
        pocetkusovtabulka.setText(String.valueOf(spolu));
        cislozvierattabulka.setText("");
        tableLayout.addView(tableRow);
    }

    private void VypisKody(){
        List<Sekcia> sekcias = db.SekciaDao().getAllSekcias();
        int spolu = 0;
        for(Sekcia sekcia:sekcias){
            View tableRow = LayoutInflater.from(this).inflate(R.layout.statistika_pocetkusov,null,false);
            TextView kodtabulka  = tableRow.findViewById(R.id.kodtabulka);
            TextView pocetkusovkodtabulka  = tableRow.findViewById(R.id.pocetkusovkodtabulka);


            kodtabulka.setText(sekcia.getCislosekcie());
            pocetkusovkodtabulka.setText(String.valueOf(sekcia.getPocetkusov()));
            kodtabulka.setText(sekcia.getCislozvierat());
            tableLayout.addView(tableRow);

            spolu +=sekcia.getPocetkusov();

        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }


}
