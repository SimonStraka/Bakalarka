package sk.tuke.bp;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import java.util.ArrayList;
import java.util.List;

public class Mazanie extends AppCompatActivity  {

    RecyclerView recyclerView;
    RecyclerView.Adapter adapter;
    List<Sekcia> sekcias;
    private SekciaAdapter.RecyclerViewClickListener listener;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_sekcie_recyclerview);


        AppDatabase db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "production")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();

        sekcias = db.SekciaDao().getAllSekcias();

        setOnClickListener();
        recyclerView = findViewById(R.id.rv_sekcie_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new SekciaAdapter(sekcias,listener);
        recyclerView.setAdapter(adapter);



    }

    private void setOnClickListener() {
        listener = new SekciaAdapter.RecyclerViewClickListener() {
            @Override
            public void onClick(View v, int position) {
                AlertDialog.Builder builder = new AlertDialog.Builder(
                        Mazanie.this
                );

                builder.setMessage("Chcete vymazať sekciu?");

                builder.setPositiveButton("Áno", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        AppDatabase db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "production")
                                .allowMainThreadQueries()
                                .fallbackToDestructiveMigration()
                                .build();
                        db.SekciaDao().Delete(sekcias.get(position));
                        sekcias.remove(position);
                        setOnClickListener();
                        recyclerView = findViewById(R.id.rv_sekcie_view);
                        recyclerView.setLayoutManager(new LinearLayoutManager(Mazanie.this));
                        adapter = new SekciaAdapter(sekcias,listener);
                        recyclerView.setAdapter(adapter);
                    }
                });

                builder.setNegativeButton("Nie", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });

                builder.show();



            }



        };
    }
}

