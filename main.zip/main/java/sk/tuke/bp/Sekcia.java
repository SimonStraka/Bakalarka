package sk.tuke.bp;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Sekcia {

    public Sekcia(String cislosekcie, String cislozvierat, int pocetkusov) {
        this.cislosekcie = cislosekcie ;
        this.cislozvierat = cislozvierat;
        this.pocetkusov = pocetkusov;
    }
    @PrimaryKey(autoGenerate = true)
    private int id;

    @ColumnInfo(name = "cislosekcie")
    private String cislosekcie;


    @ColumnInfo(name = "cislozvierat")
    private String cislozvierat;

    @ColumnInfo(name = "pocetkusov")
    private int pocetkusov;




    //Getre
   public int getId() {
       return id;
   }

    public String getCislosekcie() {return cislosekcie;
    }


    public String getCislozvierat() {

        return cislozvierat;
    }

    public int getPocetkusov() {
        return pocetkusov;
    }

    //Setre
    public void setId(int id) {
        this.id = id;
    }

    public void setCislosekcie(String cislosekcie) {
        this.cislosekcie = cislosekcie;
    }

    public void setCislozvierat(String cislozvierat) {
        this.cislozvierat = cislozvierat;
    }

    public void setPocetkusov(int pocetkusov) {
        this.pocetkusov = pocetkusov;
    }
}
