package sk.tuke.bp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class HlasenieAdapter extends RecyclerView.Adapter<HlasenieAdapter.ViewHolder>   {

        List<Hlasenie> hlasenias;

        public HlasenieAdapter(List<Hlasenie> hlasenias){
            this.hlasenias = hlasenias;

        }

    @NonNull
        @Override
        public HlasenieAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.hlasenie_row,parent,false);
            return new ViewHolder(view);

        }

        @Override
        public void onBindViewHolder(@NonNull HlasenieAdapter.ViewHolder holder, int position) {
            holder.Datum.setText(hlasenias.get(position).getDatum());
            holder.Cislosekcie.setText(hlasenias.get(position).getCislosekcie());
            holder.Cislozvierat.setText(hlasenias.get(position).getCislozvierat());
            holder.Pocetkusov.setText(String.valueOf(hlasenias.get(position).getPocetkusov()));
            holder.Cislofarmy.setText(hlasenias.get(position).getCislofarmy());
            holder.Kodudalosti.setText(hlasenias.get(position).getKodudalosti());
        }

        @Override
        public int getItemCount() {
            return hlasenias.size();
        }



        public class ViewHolder extends  RecyclerView.ViewHolder  {
            public TextView Cislosekcie;
            public TextView Cislozvierat;
            public TextView Pocetkusov;
            public TextView Cislofarmy;
            public TextView Kodudalosti;
            public TextView Datum;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                Datum = itemView.findViewById(R.id.datum);
                Cislosekcie = itemView.findViewById(R.id.nazovsekcie);
                Cislozvierat = itemView.findViewById(R.id.cislozvierat);
                Pocetkusov = itemView.findViewById(R.id.pocetkusov);
                Cislofarmy = itemView.findViewById(R.id.cislofarmy1);
                Kodudalosti = itemView.findViewById(R.id.kodudalosti);

            }

        }
}


