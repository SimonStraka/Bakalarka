package sk.tuke.bp;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import java.util.List;


public class QRkod extends AppCompatActivity {

    ImageView  qrkod;
    Button stiahnut;

    String Vysledok =" " + " ";



    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_qrkod);


        qrkod = findViewById(R.id.Qrkod);
        stiahnut = findViewById(R.id.stiahnut);

        MultiFormatWriter writer = new MultiFormatWriter();
        try{
            Vysledok = getIntent().getExtras().getString("vysledok");
            BitMatrix matrix = writer.encode(Vysledok, BarcodeFormat.QR_CODE,350,350);
            BarcodeEncoder encoder = new BarcodeEncoder();
            Bitmap bitmap =encoder.createBitmap(matrix);
            qrkod.setImageBitmap(bitmap);
            InputMethodManager manager = (InputMethodManager) getSystemService(
                    Context.INPUT_METHOD_SERVICE
            );


            stiahnut.setVisibility(View.VISIBLE);
            stiahnut.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v){
                    MediaStore.Images.Media.insertImage(getContentResolver(),bitmap,"Kód",null);
                    Toast.makeText(QRkod.this,"Kód ste stiahli do galérie",Toast.LENGTH_SHORT).show();
                }
            });

        }
        catch (WriterException e){
            e.printStackTrace();
        }



    }


}
