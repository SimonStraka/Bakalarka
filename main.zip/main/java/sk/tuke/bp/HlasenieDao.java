package sk.tuke.bp;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
interface HlasenieDao {
    @Query("SELECT * FROM hlasenie")
    List<Hlasenie> getAllHlasenias();


    @Insert
    void insertAll(Hlasenie... hlasenies);

}
