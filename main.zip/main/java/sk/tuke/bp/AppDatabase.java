package sk.tuke.bp;
import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {Sekcia.class,Hlasenie.class}, version = 10 )
public abstract class AppDatabase extends RoomDatabase {
    
    public abstract SekciaDao SekciaDao();

    public abstract HlasenieDao HlasenieDao();
}